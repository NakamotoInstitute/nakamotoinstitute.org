version = '3.4.2'
rpowid = 'M342RPOW'
